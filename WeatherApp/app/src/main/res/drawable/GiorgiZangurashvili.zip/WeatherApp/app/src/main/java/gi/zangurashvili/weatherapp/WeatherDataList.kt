package gi.zangurashvili.weatherapp

class WeatherDataList {
    val list: List<WeatherData> = arrayListOf<WeatherData>()
}