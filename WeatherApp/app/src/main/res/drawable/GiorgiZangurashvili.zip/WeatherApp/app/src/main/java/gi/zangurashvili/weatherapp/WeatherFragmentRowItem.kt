package gi.zangurashvili.weatherapp

data class WeatherFragmentRowItem(
    val description: String,
    val value: String
)
