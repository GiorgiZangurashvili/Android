package gi.zangurashvili.weatherapp

data class Wind(
    val deg: Int,
    val speed: Double
)