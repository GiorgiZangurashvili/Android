package gi.zangurashvili.weatherapp

data class Clouds(
    val all: Int
)